package com.example.ryan.google_books;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ryan on 10/14/2017.
 */

public class QueryMeThis {

    private QueryMeThis() {
    }

    public static String formatListOfAuthors(JSONArray listOfAuthors) throws JSONException {

        String stringOfAuthors = null;

        if (listOfAuthors.length() == 0) {
            return null;
        }

        for (int i = 0; i < listOfAuthors.length(); i++){
            if (i == 0) {
                stringOfAuthors = listOfAuthors.getString(0);
            } else {
                stringOfAuthors += ", " + listOfAuthors.getString(i);
            }
        }

        return stringOfAuthors;
    }


    public static List<TheBooks> extractBooks(String json) {

        List<TheBooks> booksList = new ArrayList<>();

        try {
            JSONObject jsonResult = new JSONObject(json);

            if (jsonResult.getInt("totalItems") == 0) {
                return booksList;
            }
            JSONArray jsonArray = jsonResult.getJSONArray("items");

            for (int i = 0; i < jsonArray.length(); i++){
                JSONObject objectForBook = jsonArray.getJSONObject(i);

                JSONObject objectForInfo = objectForBook.getJSONObject("volumeInfo");

                String title = objectForInfo.getString("title");
                JSONArray authorsArray = objectForInfo.getJSONArray("authors");
                String authors = formatListOfAuthors(authorsArray);

                TheBooks book = new TheBooks(authors, title);
                booksList.add(book);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return booksList;
    }
}