package com.example.ryan.google_books;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Ryan on 10/14/2017.
 */

public class TheBooks implements Parcelable {

    String author;
    String title;

    public TheBooks(String author, String title) {
        this.author = author;
        this.title = title;
    }

    protected TheBooks(Parcel in) {
        author = in.readString();
        title = in.readString();
    }

    public static final Creator<TheBooks> CREATOR = new Creator<TheBooks>() {
        @Override
        public TheBooks createFromParcel(Parcel in) {
            return new TheBooks(in);
        }

        @Override
        public TheBooks[] newArray(int size) {
            return new TheBooks[size];
        }
    };

    public String getAuthor() {
        return author;
    }

    public String getTitle() {
        return title;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(author);
        parcel.writeString(title);
    }
}
